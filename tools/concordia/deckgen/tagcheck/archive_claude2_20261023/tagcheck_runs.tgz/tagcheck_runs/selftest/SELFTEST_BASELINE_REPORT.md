# Reverse check of the tags (blind reader)

Run `selftest-baseline`. A blind reader saw only each card's tags and wrote the ability text they describe; that text was scored against the real Oracle text. Tool: `deckgen/tagcheck/reverse_check.py`. Similarity = 0.4 tf-idf cosine + 0.4 concept F1 + 0.2 number F1 (bands: good >= 0.7, partial 0.4-0.7, gap < 0.4; thresholds are unvalidated until a reader run is compared with a hand check). Mana-cost symbols are removed from both texts (costs are not tags).

## Summary

| cards | with text | mean similarity | good | partial | gap | source card ranked #1 | in top 5 | median rank |
|---|---|---|---|---|---|---|---|---|
| 353 | 348 | 0.613 | 127 | 165 | 56 | 154 | 236 | 2 |

Reader integrity: 0 outputs contain the card name (should be 0); 0 cards the reader says it recognised (a high rate weakens the test).

## What the tags failed to carry (concepts in the real text, absent from the reconstruction)

| concept | cards | share |
|---|---|---|
| creature | 163 | 46% |
| target | 92 | 26% |
| you_control | 78 | 22% |
| opponent | 65 | 18% |
| each_all | 51 | 14% |
| may | 35 | 10% |
| pump | 35 | 10% |
| hand | 26 | 7% |
| tapped | 23 | 6% |
| land | 22 | 6% |
| cast | 19 | 5% |
| battlefield | 17 | 4% |
| tap | 13 | 3% |
| enchant | 13 | 3% |
| eot | 12 | 3% |
| library | 12 | 3% |
| up_to | 11 | 3% |
| graveyard | 11 | 3% |
| reveal | 11 | 3% |
| choose | 10 | 2% |
| mana | 10 | 2% |
| x_value | 10 | 2% |
| attack | 10 | 2% |
| instead | 9 | 2% |
| block | 9 | 2% |

## What the reader added that the real text lacks (tags that over-claim or mislead)

| concept | cards |
|---|---|
| return | 12 |
| mana | 8 |
| lifegain | 4 |
| token | 4 |
| graveyard | 3 |
| eot | 2 |
| draw | 2 |
| dies | 2 |
| trigger_when | 2 |
| search | 2 |
| hand | 2 |
| target | 1 |
| counters | 1 |

## Lowest 25 cards

| Card | sim | missing concepts | extra concepts | real text | reader text |
|---|---|---|---|---|---|
| Dragonlord's Servant | 0.00 | cast |  | Dragon spells you cast cost {1} less to cast. |  |
| Fervor | 0.00 | creature haste kw:haste you_control |  | Creatures you control have haste. (They can attack and {T} as soon as they come under your control.) |  |
| Icy Blast | 0.00 | creature tap target x_value you_control |  | Tap X target creatures. / Ferocious — If you control a creature with power 4 or greater, those creatures don't untap during their controllers' next untap steps. |  |
| Dramatic Reversal | 0.00 | each_all tap you_control |  | Untap all nonland permanents you control. |  |
| Laboratory Maniac | 0.00 | draw instead library |  | If you would draw a card while your library has no cards in it, you win the game instead. |  |
| Propaganda | 0.00 | attack creature each_all |  | Creatures can't attack you unless their controller pays {2} for each creature they control that's attacking you. |  |
| Exhaustion | 0.00 | creature land opponent tap |  | Creatures and lands target opponent controls don't untap during their next untap step. |  |
| Benalish Marshal | 0.00 | creature pump you_control |  | Other creatures you control get +1/+1. |  |
| Ghostly Prison | 0.00 | attack creature each_all |  | Creatures can't attack you unless their controller pays {2} for each creature they control that's attacking you. |  |
| Glorious Anthem | 0.00 | creature pump you_control |  | Creatures you control get +1/+1. |  |
| Rishkar's Expertise | 0.16 | cast creature hand mana may you_control |  | Draw cards equal to the greatest power among creatures you control. / You may cast a spell with mana value 5 or less from your hand without paying its mana cost. | draw a card |
| Watcher for Tomorrow | 0.20 | battlefield exile hand tapped trigger_when |  | Hideaway 4 (When this permanent enters, look at the top four cards of your library, exile one face down, then put the rest on the bottom of your library.) / Watcher for Tomorrow enters tapped. / When Watcher for Tomorrow leaves the battlefield, put the exiled card into its owner's hand. | hideaway |
| Stonybrook Banneret | 0.20 | cast |  | Islandwalk (This creature can't be blocked as long as defending player controls an Island.) / Merfolk spells and Wizard spells you cast cost {1} less to cast. | landwalk |
| Scorching Dragonfire | 0.21 | creature dies eot exile instead target |  | Scorching Dragonfire deals 3 damage to target creature or planeswalker. If that creature or planeswalker would die this turn, exile it instead. | deals damage |
| Skinrender | 0.26 | counters creature target |  | When Skinrender enters, put three -1/-1 counters on target creature. | when enters the battlefield |
| Overrun | 0.27 | creature kw:trample pump you_control |  | Creatures you control get +3/+3 and gain trample until end of turn. | until end of turn |
| Dark Bargain | 0.27 | graveyard hand library look_top |  | Look at the top three cards of your library. Put two of them into your hand and the other into your graveyard. Dark Bargain deals 2 damage to you. | deals damage |
| Lightning Mare | 0.27 | block creature pump |  | This spell can't be countered. / Lightning Mare can't be blocked by blue creatures. / {1}{R}: Lightning Mare gets +1/+0 until end of turn. | until end of turn |
| Make a Stand | 0.28 | creature kw:indestructible pump you_control |  | Creatures you control get +1/+0 and gain indestructible until end of turn. (Damage and effects that say "destroy" don't destroy them.) | until end of turn |
| Grasp of Darkness | 0.29 | creature pump target |  | Target creature gets -4/-4 until end of turn. | until end of turn |
| Titanic Growth | 0.29 | creature pump target |  | Target creature gets +4/+4 until end of turn. | until end of turn |
| Elite Scaleguard | 0.29 | counters creature opponent tap target you_control |  | When Elite Scaleguard enters, bolster 2. (Choose a creature with the least toughness among creatures you control and put two +1/+1 counters on it.) / Whenever a creature you control with a +1/+1 counter on it attacks, tap target creature defending player controls. | when enters the battlefield. / whenever attacks |
| Militia Bugler | 0.29 | creature hand library look_top may reveal |  | Vigilance (Attacking doesn't cause this creature to tap.) / When Militia Bugler enters, look at the top four cards of your library. You may reveal a creature card with power 2 or less from among them and put it into your hand. Put the rest on the bottom of your library in a random order. | vigilance. / when enters the battlefield |
| Return of the Wildspeaker | 0.30 | choose creature pump you_control |  | Choose one — / • Draw cards equal to the greatest power among non-Human creatures you control. / • Non-Human creatures you control get +3/+3 until end of turn. | draw a card. / until end of turn |
| Kami of Whispered Hopes | 0.31 | counters instead x_value you_control |  | If one or more +1/+1 counters would be put on a permanent you control, that many plus one +1/+1 counters are put on that permanent instead. / {T}: Add X mana of any one color, where X is Kami of Whispered Hopes's power. | add mana. / {t} |

## Highest 5 cards

| Card | sim | real text | reader text |
|---|---|---|---|
| Typhoid Rats | 1.00 | Deathtouch (Any amount of damage this deals to a creature is enough to destroy it.) | deathtouch |
| Thornweald Archer | 1.00 | Reach, deathtouch | deathtouch. / reach |
| Deadly Recluse | 1.00 | Reach (This creature can block creatures with flying.) / Deathtouch (Any amount of damage this deals to a creature is enough to destroy it.) | reach. / deathtouch |
| Ambush Viper | 1.00 | Flash / Deathtouch | flash. / deathtouch |
| Tajuru Pathwarden | 1.00 | Vigilance, trample | vigilance. / trample |

## Known limits

- Mana-cost amounts, power/toughness and flavour are not tags; they are excluded, not scored as gaps.
- Concept and number matching are regex based; a rephrased but equal ability can score low. Read the lowest-25 table, not only the number.
- A reader that knows the real card from the tags (famous cards) inflates the score; see `recognised`.
- Similarity bands have not been checked against human judgement yet.
