# forge-ai-lab reply (tag data analysis, read-only, H55 held)
Data seen: TIER1_TAGS.toon 2131 cards. forge_ai line: 1941 AILogic=- ; 84 carry RemoveDeck (78 plain); ~25 have AIPreference; named AILogic ~100 cards (Pump 26, Curse 10, MakeUnblockable 8, AtOppEOT 6, Aristocrat 5, PoolExtraMana 4, Fog 4, ManaRitual 3, Never 3, rest singles).
Caveat: counts are tier 1 only; sample of tag counts among RemoveDeck cards, not a statistical test.

## 1 ANALYSIS: tags vs Forge AI
analysis[6]{id|finding}:
  A1|RemoveDeck:All cards (84) are the ones the AI deck builder drops and the AI cannot play well. Their tags cluster: sacrifice_outlet 13, draw 13, token_make 10, optional 11, restrict 6, mana_source 6, discard 5, pump_team/pump_single 8 (e.g. Buried Alive, Sanguine Bond, Coretapper, Elvish Promenade, Might of Alara). Pattern = effects needing a choice (optional, sac as cost, X, target-by-choice) or a combo payoff the AI has no logic for.
  A2|AILogic=Curse/Pump/Fog/MakeUnblockable/AtOppEOT/Aristocrat/Never are direct decision types. Each maps to a tag family: Curse->aura/curse + restrict/pump negative on opponent; Pump->pump_single/pump_team + duration:eot; Fog->fog/prevent damage; MakeUnblockable->evasion grant; AtOppEOT->flash/instant-speed draw or token; Aristocrat->sacrifice_outlet; Never->card the AI refuses to cast (Tavern Swindler, Watchers of the Dead, Viashino Lashclaw).
  A3|AILogic=- is 91% of cards: the AI uses generic per-API logic (DamageDealAi, PumpAi, TokenAi...). So the useful AI predictor is the verb/API tag plus conditions, not AILogic itself.
  A4|Likely misplay combos (hypotheses to test later, no sim now): optional + sacrifice_outlet (AI sacs at wrong time); x_* tags (x_def:..., pump_power:-x) without a clear target filter; reflexive + condition chains; scales:graveyard/scales:X where the AI does not value the count; duration:eot pumps outside combat; trigger:attacks pump on a creature the AI will not attack with; kw:morph/flip-up cards; put_onto_battlefield from graveyard with no reanimation logic.
  A5|Unplayable-by-design flags: card has RemoveDeck AND appears in a tier 1 deck = check list (AI deck should not hold it if AI never plays it). Not done yet; needs the flag cross-check below.
  A6|AIPreference (~25 cards) = sacrifice/discard/target preference hints. Tag-side equivalent: sacrifice_outlet, discard, cost:sacrifice. Not exposed in tags today.

## 2 UTILITY for AI-lab scope
utility[6]{id|use|tags_needed}:
  U1|Group cards by AI decision type (attack, block, removal, pump/trick, token, mana, draw, sac, counter) for the DECISION_LOGIC tables|verb tags: damage, burn, destroy, exile, bounce, pump_*, draw, token_make, mana_source, counter, sacrifice_outlet + trigger:* + duration:eot
  U2|Pick test cards for sims by decision type (one clean exemplar per tag combo, 40-card minideck --test list)|any 2-3 tag AND query over TIER1_TAGS; prefer cards with AILogic=-  (plain logic) as controls
  U3|Check flagged cards (AI_FLAGGED_CARDS.md): list cards with RemoveDeck whose tags show no real blocker (candidates to unflag, like 002/003 Thwart, Vine Snare, Endure)|forge_ai RemoveDeck + tags; need a column showing the unflag reason class
  U4|Find combat-trick cards (pump_single + duration:eot + instant) for the trick-use analysis and flash/AtOppEOT timing|cardtype:instant pump_single duration:eot
  U5|Commander-play study: legendary + cardtype:creature + kw:partner/commander-cost tags to split commander logic by deck type|supertype:legendary, kw:partner, trigger:*
  U6|Sim coverage check: which tag combos appear in a tier 1 deck but never in a phase-log digest (digest rows are by card name, joinable)|card name key, same tags

## 3 SUGGESTIONS
suggestions[10]{id|finding|suggestion|why}:
  S1|forge_ai line lacks the API/verb the AI uses (DamageDealAi etc.); "AILogic=-" says nothing|add forge_ai:api=<ApiType> and the AI file class (e.g. api=Pump, class=PumpAi) per ability|lets grouping by AI decision code without reading scripts
  S2|RemoveDeck shows only "RemoveDeck", not All vs Random vs Ai, and not why|keep the exact value (RemoveDeck:All / Random / AI) and add reason class tag (needs_choice, combo_payoff, unplayable_cost)|check flagged cards for unflag candidates; Nihil Spellbomb, Coretapper, Weathered Runestone are plain utility, likely mis-flagged
  S3|AIPreference value is dropped|keep text (e.g. SacCost$Creature.token, DiscardCost$..) as ai_pref:<type>:<filter>|explains Aristocrat/sac behavior (Nantuko Husk, Phyrexian Ghoul)
  S4|duration:eot is on pumps, but "attacks-only/combat-only" use is not tagged|add timing:combat vs timing:any for pumps/tricks (Might of Alara, Elvish Promenade-like, AILogic=Pump cards)|trick timing is the most common AI misplay class
  S5|"optional" is one flat tag; may-effects with a cost vs plain "may"|split optional:cost vs optional:free|AI decides these by different code paths
  S6|X cost vs X in the effect not clearly separated (x_def:valid_artifact_you_ctrl_plus_y on Armix)|tag x_kind:cost|count|target-dependent|AI X-spell logic picks X only for cost X; count-based X is automatic
  S7|Targets for AI (own vs opponent vs any) given as target_filter:defenderctrl only in places|always emit target_side:own|opp|any|removal vs buff vs curse grouping (Curse cards: Mana Chains, So Tiny, Frogify)
  S8|AILogic=Never cards (Tavern Swindler, Watchers of the Dead, Viashino Lashclaw) not distinguished|add ai_never tag|these will never be cast in sims; exclude from deck/test picks
  S9|no tag marks cards whose value depends on the AI attacking/blocking (Aristocrat, Fog, MakeUnblockable)|add ai_dep:combat|attack/block logic study, picks test cards
  S10|Token/ETB cards show token_make but not token power (AI values tokens by P/T)|add token_pt:<p>/<t> and token_count:<n>|token logic analysis, tempo
