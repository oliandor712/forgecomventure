#!/usr/bin/env python3
"""Blind tag test: can a reader rebuild a card's rules text from its tags alone?
  python3 blind_test.py build <n> <seed> <round> <blind_dir> <key_dir> [--same-as <key_dir_of_earlier_round>]
      samples n tier 1 cards (staged + live decks; no basic lands; only cards that carry an ability tag), tags them with the CURRENT tagger,
      writes blind_dir/batch_K.txt (100 cards each: id, tags, linked groups; no names, no Oracle text) and key_dir/key_K.json (id, name, tags, Oracle text of every face).
      --same-as reuses the exact cards of an earlier round (to measure a fix on the same cards).
      --exclude <key_dir> (repeatable) leaves out the cards of an earlier sample, for a different sample.
  python3 blind_test.py score <key_dir> <grade_dir>      aggregates the graders' TSV files (id<TAB>verdict<TAB>gap labels<TAB>wrong tags<TAB>note)
Key files must stay out of the readers' reach (outside the repo and the readers' folder)."""
import os, sys, glob, json, random, re, collections
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import tag_run as TR

BASICS = ("supertype:", "cardtype:", "type:", "landtype:", "kw:", "num:", "color:", "alt_", "adventure", "mdfc")


def tier1_names():
    names = set()
    for pat in ("forge-gui/res/adventure/Concordia/staging_t1_fresh/decks/tier1/*.dck", "forge-gui/res/adventure/Concordia/decks/tier1/*.dck"):
        for p in glob.glob(os.path.join(TR.ROOT, pat)): names |= set(TR.deck_cards(p))
    return sorted(names)


def oracle_of(text):
    faces = text.split("\nALTERNATE")
    out = []
    for f in faces:
        nm = re.search(r"^Name:(.*)$", f, re.M)
        o = next((l[7:] for l in f.split("\n") if l.startswith("Oracle:")), "")
        out.append(((nm.group(1) + ": ") if nm and len(faces) > 1 else "") + o.replace("\\n", " / "))
    return "  //  ".join(out)


def build(n, seed, rnd, blind_dir, key_dir, same_as=None, exclude=None):
    mg = TR.mtgish_load()
    skip = set()
    for ed in (exclude or []):
        for k in glob.glob(os.path.join(ed, "key_*.json")): skip |= {c["name"] for c in json.load(open(k, encoding="utf-8"))}
    if same_as:
        chosen = []
        for k in sorted(glob.glob(os.path.join(same_as, "key_*.json"))): chosen += [c["name"] for c in json.load(open(k))]
    else:
        pool = []
        for nme in tier1_names():
            if nme in skip: continue
            t = TR.find_text(nme)
            if not t: continue
            r = TR.record(nme, t, mg)
            if "supertype:basic" in r["tags"]: continue
            if not [x for x in r["tags"] if not x.startswith(BASICS)]: continue
            pool.append(nme)
        random.Random(seed).shuffle(pool)
        chosen = pool[:n]
    os.makedirs(blind_dir, exist_ok=True); os.makedirs(key_dir, exist_ok=True)
    for f in glob.glob(os.path.join(blind_dir, "batch_*.txt")) + glob.glob(os.path.join(key_dir, "key_*.json")): os.remove(f)
    for b in range(0, len(chosen), 100):
        blind, key = [], []
        for i, nme in enumerate(chosen[b:b + 100], 1):
            t = TR.find_text(nme)
            r = TR.record(nme, t, mg)
            cid = "%d.%d" % (b // 100 + 1, i)
            grp = "; ".join("%s: %s" % (k, " ".join(v)) for k, v in r["groups"].items())
            blind.append("%s | tags: %s | groups: %s" % (cid, " ".join(r["tags"]), grp))
            key.append(dict(id=cid, name=nme, tags=r["tags"], groups=r["groups"], oracle=oracle_of(t)))
        open(os.path.join(blind_dir, "batch_%d.txt" % (b // 100 + 1)), "w", encoding="utf-8").write("\n".join(blind) + "\n")
        json.dump(key, open(os.path.join(key_dir, "key_%d.json" % (b // 100 + 1)), "w", encoding="utf-8"))
    print("round", rnd, len(chosen), "cards in", (len(chosen) + 99) // 100, "batches")


def score(key_dir, grade_dir):
    ver = collections.Counter(); gaps = collections.Counter(); wrong = collections.Counter(); n = 0; ex = collections.defaultdict(list)
    names = {}
    for k in glob.glob(os.path.join(key_dir, "key_*.json")):
        for c in json.load(open(k, encoding="utf-8")): names[c["id"]] = c["name"]
    for f in sorted(glob.glob(os.path.join(grade_dir, "grade_*.tsv"))):
        for ln in open(f, encoding="utf-8"):
            p = ln.rstrip("\n").split("\t")
            if len(p) < 2 or p[0] not in names: continue
            n += 1; ver[p[1].strip().upper()] += 1
            for g in re.split(r"[;,]\s*", p[2] if len(p) > 2 else ""):
                g = g.strip()
                if g and g != "-":
                    gaps[g] += 1
                    if len(ex[g]) < 4: ex[g].append(names[p[0]])
            for w in re.split(r"[;,]\s*", p[3] if len(p) > 3 else ""):
                w = w.strip()
                if w and w != "-": wrong[w] += 1
    print("graded", n, dict(ver))
    print("GAPS:", gaps.most_common(40))
    print("WRONG TAGS:", wrong.most_common(30))
    return n, ver, gaps, wrong, ex


if __name__ == "__main__":
    a = sys.argv[1:]
    if a and a[0] == "build":
        same = a[a.index("--same-as") + 1] if "--same-as" in a else None
        excl = [a[i + 1] for i, x in enumerate(a) if x == "--exclude"]
        build(int(a[1]), int(a[2]), a[3], a[4], a[5], same, excl)
    elif a and a[0] == "score": score(a[1], a[2])
    else: print(__doc__)
