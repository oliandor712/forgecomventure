"""Second tag pass (human_logic.toon H56, H58): tags for the gaps found by the blind tag tests (tags/TAG_BLIND_TEST_20.md, tags/blind/*).
gap_groups(lines, sv, types, text) -> {group id: [tags]}; group ids follow tag_extra.extra (cN = the N-th A/S/T/R line, cN.k = its k-th chained sub-ability).
Every family here is logged in tags/NEW_TAGS_FOR_APPROVAL.md; the user approved the gap families on 2026-10-22. Source: the Forge script only.
Rounds: v1 (amounts, grants, phases, conditions, filters), v2 (player scope, optional/pay, cost parts, limits, generic triggers, ability words, sagas, base P/T, block restrictions, more APIs)."""
import re

COLORS = {"white": "white", "blue": "blue", "black": "black", "red": "red", "green": "green"}
CARDTYPES = {"artifact", "creature", "enchantment", "land", "planeswalker", "instant", "sorcery", "battle", "permanent", "card", "kindred"}
HANDLED_MODES = {"ChangesZone", "ChangesZoneAll", "SpellCast", "SpellCastOrCopy", "Attacks", "AttackersDeclared", "AttackerBlocked", "AttackerUnblocked", "Discarded", "Phase", "DamageDone", "Blocks"}
KWCOST = {"kicker", "multikicker", "cycling", "equip", "flashback", "reinforce", "evoke", "madness", "morph", "megamorph", "echo", "embalm", "eternalize", "escape", "bestow", "prowl",
          "replicate", "unearth", "entwine", "buyback", "overload", "surge", "spectacle", "dash", "blitz", "mutate", "ninjutsu", "transmute", "channel", "outlast", "warp", "splice",
          "cumulative_upkeep", "typecycling", "landcycling", "forecast", "suspend", "fortify", "level_up", "monstrosity", "adapt", "scavenge", "crew", "ward", "disturb", "foretell", "plot", "prototype", "offspring"}
GENERIC_API = {"ChooseColor": "choose_color", "ChooseType": "choose_type", "ChooseCard": "choose_card", "ChooseNumber": "choose_number", "Regenerate": "regenerate", "RegenerateAll": "regenerate", "Explore": "explore", "Connive": "connive", "Surveil": "surveil", "Investigate": "investigate",
               "Proliferate": "proliferate", "Tap": "tap", "TapAll": "tap", "Fight": "fight", "Goad": "goad", "Populate": "populate", "Manifest": "manifest",
               "Bolster": "bolster", "Incubate": "incubate", "RollDice": "roll_dice", "FlipACoin": "flip_coin", "Radiation": "radiation", "Clash": "clash",
               "Monstrosity": "monstrosity", "Adapt": "adapt", "Support": "support", "TimeTravel": "time_travel", "Venture": "venture", "Reveal": "reveal",
               "RevealHand": "reveal_hand", "Counter": "counter_spell", "CopySpellAbility": "copy_spell", "PreventDamage": "prevent_damage", "Protection": "protection_grant",
               "Draft": "draft", "Vote": "vote", "Encode": "encode", "Remove": "remove_from_combat", "RemoveFromCombat": "remove_from_combat",
               "SetState": "set_state", "Bond": "bond", "Detain": "detain", "BecomeMonarch": "monarch", "TakeInitiative": "initiative", "Seek": "seek", "Smeld": "meld",
               "Amass": "amass"}


def tok(s): return re.sub(r"[^a-z0-9]+", "_", str(s).lower()).strip("_")


def snake_words(s): return tok(re.sub(r"([a-z])([A-Z])", r"\1_\2", str(s)))


def params(body):
    d = {}
    for item in body.split(" | "):
        m = re.match(r"^(\w+)\$ ?(.*)$", item)
        if m: d[m.group(1)] = m.group(2)
    return d


def valid(v):
    """a Forge valid-string such as 'Creature.Red+YouCtrl', 'Card.nonCreature', 'Land.YouCtrl', 'Creature.!token', 'Creature.powerLE2'
    -> dict(types, colors, scope, filters, combo). Alternatives are split on ','. combo = one tag word per alternative ('Artifact.Creature' -> artifact_creature,
    'Creature.Golem' -> golem)."""
    types, colors, scope, filters, combo = [], [], [], [], []
    for alt in str(v).split(","):
        parts = [x for x in re.split(r"[.+]", alt) if x]
        if not parts: continue
        first = parts[0]
        at = []
        if first not in ("Card", "Any", "Self", "Targeted"): at.append(tok(first))
        for r in parts[1:]:
            if r in ("YouCtrl",): scope.append("you_control")
            elif r in ("YouOwn",): scope.append("you_own")
            elif r in ("OppCtrl", "YouDontCtrl"): scope.append("opp_control")
            elif r in ("OppOwn",): scope.append("opp_own")
            elif r.lower() in COLORS: colors.append(tok(r))
            elif r == "!token": filters.append("nontoken")
            elif r == "token": filters.append("token")
            elif r == "Other": filters.append("other")
            elif r == "Self": filters.append("self")
            elif re.match(r"^with(out)?[A-Z]", r): filters.append(("without_" if r.startswith("without") else "with_") + snake_words(re.sub(r"^with(out)?", "", r)))
            elif r.startswith("non"): filters.append("non" + tok(r[3:]))
            elif r.startswith("!"): filters.append("not_" + tok(r[1:]))
            elif re.match(r"^(power|toughness|cmc)(LE|GE|EQ|LT|GT)\d+$", r):
                m = re.match(r"^(power|toughness|cmc)(LE|GE|EQ|LT|GT)(\d+)$", r)
                filters.append("%s_%s_%s" % (m.group(1), m.group(2).lower(), m.group(3)))
            elif r[0].isupper(): at.append(tok(r))
            else: filters.append(tok(r))
        types += at
        subs = [t for t in at if t not in CARDTYPES]
        if subs: combo.append("_".join(subs))
        elif at: combo.append("_".join(at))
    return dict(types=list(dict.fromkeys(types)), colors=list(dict.fromkeys(colors)), scope=list(dict.fromkeys(scope)), filters=list(dict.fromkeys(filters)), combo=list(dict.fromkeys(combo)))


def signed(v):
    v = str(v).strip()
    if re.match(r"^[+-]?\d+$", v): return v if v[0] in "+-" else "+" + v
    if re.match(r"^[+-]?X$", v): return ("-" if v[0] == "-" else "+") + "x"
    return "+x"


def cost_mana(cost):
    c = re.sub(r"\w+<[^>]*>", "", cost or "")
    n, cols, x = 0, [], False
    for t in c.split():
        if t.isdigit(): n += int(t)
        elif t == "X": x = True
        elif re.match(r"^[WUBRG]$", t): n += 1; cols.append({"W": "white", "U": "blue", "B": "black", "R": "red", "G": "green"}[t])
        elif re.match(r"^[WUBRG]/[WUBRGP]$|^2/[WUBRG]$", t): n += 1
        elif t == "C": n += 1
    return n, list(dict.fromkeys(cols)), x


def cost_generic(cost):
    """generic part of the mana cost and the coloured symbols in order ({1}{U}{U} -> 1, 'uu')"""
    c = re.sub(r"\w+<[^>]*>", "", cost or "")
    g, syms = 0, ""
    for t in c.split():
        if t.isdigit(): g += int(t)
        elif re.match(r"^[WUBRG]$", t): syms += t.lower()
    return g, syms


def cost_parts(cost):
    """cost components beyond mana, tap and sacrifice target: counters removed, energy, life, exile, return, mill, tap-other"""
    out = []
    for m in re.finditer(r"(?:SubCounter|RemoveAnyCounter)<(\w+)/(\w+)", cost or ""):
        if m.group(2) != "LOYALTY": out += ["cost:remove_counter", "cost_counter_amount:" + (m.group(1).lower() if m.group(1).isdigit() else "x"), "cost_counter_type:" + tok(m.group(2))]
    m = re.search(r"PayEnergy<(\w+)>", cost or "")
    if m: out += ["cost:energy", "cost_energy_amount:" + (m.group(1) if m.group(1).isdigit() else "x")]
    m = re.search(r"PayLife<(\w+)>", cost or "")
    if m: out.append("cost_life_amount:" + (m.group(1) if m.group(1).isdigit() else "x"))
    m = re.search(r"Sac<(\w+)/", cost or "")
    if m: out.append("cost_sacrifice_amount:" + (m.group(1) if m.group(1).isdigit() else "x"))
    m = re.search(r"Discard<(\w+)/", cost or "")
    if m: out.append("cost_discard_amount:" + (m.group(1) if m.group(1).isdigit() else "x"))
    if "Exile<" in (cost or "") or "ExileFromGrave<" in (cost or ""): out.append("cost:exile")
    if "Return<" in (cost or ""): out.append("cost:return_to_hand")
    if "Mill<" in (cost or ""): out.append("cost:mill")
    if "tapXType<" in (cost or ""): out.append("cost:tap_other")
    if "AddCounter<" in (cost or "") and "LOYALTY" not in cost: out.append("cost:add_counter")
    return out


def x_def(sv, texts):
    """what X means: SVar:X:Count$... -> x_def:<last part>, x_of:<counted type>"""
    out = []
    if not any(re.search(r"\bX\b", t) for t in texts): return out
    d = sv.get("X", "")
    mm = re.search(r"/(Plus|Minus|Times|Half\w*|Divide\w*)\.?(\w*)", d)
    if mm: out.append(("x_mod:%s_%s" % (mm.group(1).lower(), mm.group(2).lower())) if mm.group(2) else "x_mod:" + mm.group(1).lower())
    if not d.startswith("Count$"):
        base = d.split("/")[0]
        if "$" in base:
            out += ["x_def:" + snake_words(base.split("$")[-1]), "x_scope:" + snake_words(base.split("$")[0])]
        return out
    parts = d.split("$")
    last = snake_words(parts[-1])
    out.append("x_def:" + last)
    if len(parts) > 2 and parts[1].startswith(("Valid ", "ValidAll ")):
        v = valid(parts[1].split(" ", 1)[1])
        for t in v["types"]: out.append("x_of:" + t)
    return out


def player_of(v):
    v = str(v)
    if "Opponent" in v: return "opponent"
    if v in ("Player", "Player.Active") or v == "EachPlayer": return "each"
    if v in ("You", "Self") or v.startswith("You"): return "you"
    if "Targeted" in v or "Targeted" == v: return "target"
    return ""


def gap_groups(lines, sv, types, text):
    groups = {}
    bodies = []
    for l in lines:
        m = re.match(r"^(A|S|T|R):(.*)$", l)
        if m: bodies.append((m.group(1), m.group(2), l))
    seen = set()
    dice_range = {}

    def chain(b):
        out = [b]
        p = params(b)
        for k in ("Execute", "SubAbility", "Choices", "RepeatSubAbility", "FallbackAbility", "ResultSubAbilities"):
            for nx in re.split(r"[ ,]+", p.get(k, "")):
                if k == "ResultSubAbilities" and ":" in nx:
                    rng, nx = nx.split(":", 1)
                    dice_range[nx] = rng
                if nx in sv and nx not in seen:
                    seen.add(nx); out += chain(sv[nx])
        return out

    # enchant / equip targets on K: lines
    for l in lines:
        m = re.match(r"^K:Enchant:(.*)$", l)
        if m:
            v = valid(m.group(1).split(":")[0])
            for t in v["types"]: groups.setdefault("k_enchant", []).append("enchant_target:" + t)
            for f in v["filters"]: groups.setdefault("k_enchant", []).append("enchant_filter:" + f)
            for s in v["scope"]: groups.setdefault("k_enchant", []).append("enchant_scope:" + s)

    for l in lines:
        m = re.match(r"^K:([^:]+):(.*)$", l)
        if m:
            kwn = tok(m.group(1))
            for part in m.group(2).split(":")[-1:]:   # the cost is the last part (Reinforce:1:1 W)
                part = part.strip()
                if not re.match(r"^[\dXWUBRGCP/ ]+$", part): continue
                if part.isdigit() and kwn not in KWCOST: continue
                if not (re.search(r"[WUBRGCX]", part) or part.isdigit()): continue
                groups.setdefault("k_" + kwn, []).append("kw_cost:%s:%s" % (kwn, tok(part)))

    for n_, (kind, body, line) in enumerate(bodies, 1):
        main = "c%d" % n_
        p = params(body)

        def add(gid, *t): groups.setdefault(gid, []).extend(t)
        # ----- ability word (Landfall, Adamant, Threshold, Heroic, Raid ...)
        desc = p.get("TriggerDescription", "") + p.get("SpellDescription", "") + p.get("Description", "")
        mw = re.match(r"^\s*([A-Z][a-z]+(?: [A-Z][a-z]+)?) —", desc)
        if mw: add(main, "ability_word:" + tok(mw.group(1)))
        # ----- cost
        if kind == "A" and p.get("Cost"):
            n, cols, x = cost_mana(p["Cost"])
            if n or x:
                add(main, "cost_mana_amount:" + ("x" if x and not n else str(n)))          # total mana value of the mana part ({1}{U} = 2, {U} = 1)
                gen, syms = cost_generic(p["Cost"])
                add(main, "cost_generic:" + ("x" if x and not gen else str(gen)), "cost_symbols:" + (syms or "none"))
                for c in cols: add(main, "cost_color:" + c)
            for t in cost_parts(p["Cost"]): add(main, t)
        if p.get("ActivationLimit"):
            add(main, "limit_per_turn:" + p["ActivationLimit"])
        if p.get("PlayerTurn") == "True": add(main, "activate_only:your_turn")
        if kind == "A" and (p.get("SorcerySpeed") == "True" or p.get("ActivationPhases") == "Main1,Main2" and p.get("PlayerTurn") == "True" and "Activate only as a sorcery" in desc): add(main, "sorcery_speed")
        if p.get("ActivationPhases"): add(main, "activate_only:" + tok(p["ActivationPhases"].split(",")[0]))
        # ----- triggers
        if kind == "T":
            mode = p.get("Mode", "")
            vc = valid(p.get("ValidCard", ""))
            if mode not in HANDLED_MODES and mode: add(main, "trigger:" + snake_words(mode))
            if p.get("TriggerPlayer") or p.get("ValidPlayer") or p.get("ValidActivatingPlayer"):
                pv = p.get("ValidPlayer") or p.get("ValidActivatingPlayer") or p.get("TriggerPlayer")
                if mode != "Phase": add(main, "trigger_player:" + ("you" if pv == "You" else "opponent" if "Opp" in pv else "each"))
            if mode == "Phase":
                add(main, "trigger:phase", "trigger_phase:" + tok(p.get("Phase", "")))
                vp = p.get("ValidPlayer", "")
                add(main, "trigger_player:" + ("you" if vp == "You" else "opponent" if "Opponent" in vp else "each"))
            elif mode in ("ChangesZone", "ChangesZoneAll"):
                for t in vc["combo"]: add(main, "trigger_filter:" + t)
                for f in vc["filters"]:
                    if f not in ("self",): add(main, "trigger_filter:" + f)
                for s in vc["scope"]: add(main, "trigger_control:" + s)
                if p.get("Destination") == "Battlefield" and vc["types"] == ["land"] and "you_control" in vc["scope"]: add(main, "landfall")
                if p.get("Origin") and p.get("Origin") not in ("Any", "Battlefield"): add(main, "trigger_from:" + tok(p["Origin"]))
                if p.get("Destination") and p.get("Destination") not in ("Battlefield", "Graveyard"): add(main, "trigger_to:" + tok(p["Destination"]))
            elif mode in ("SpellCast", "SpellCastOrCopy"):
                for f in vc["filters"]: add(main, "trigger_filter:" + f)
                for t in vc["combo"]: add(main, "trigger_filter:" + t)
                vp = p.get("ValidActivatingPlayer", "")
                if vp: add(main, "trigger_caster:" + ("you" if vp == "You" else "opponent" if "Opp" in vp else "each"))
                if p.get("TargetsValid") or "Targets" in " ".join(p): add(main, "trigger_targets:" + tok(p.get("TargetsValid", "self")))
            elif mode == "DamageDone":
                add(main, "trigger:combat_damage" if p.get("CombatDamage") == "True" else "trigger:damage")
                src = p.get("ValidSource", "")
                if "Self" in src: add(main, "trigger_source:self")
                elif "EquippedBy" in src: add(main, "trigger_source:equipped")
                elif "EnchantedBy" in src: add(main, "trigger_source:enchanted")
                elif src:
                    vs = valid(src)
                    for t in vs["combo"]: add(main, "trigger_source:" + t)
                    for s in vs["scope"]: add(main, "trigger_control:" + s)
                tg = p.get("ValidTarget", "")
                for w in ("Player", "Creature", "Battle", "Planeswalker"):
                    if w in tg: add(main, "trigger_victim:" + w.lower())
                if tg and "Opponent" in tg: add(main, "trigger_victim:opponent")
                vt = valid(tg) if tg else None
                if vt:
                    for t in vt["combo"]:
                        if t not in ("player", "creature", "battle", "planeswalker"): add(main, "trigger_victim:" + t)
            elif mode in ("Attacks", "AttackersDeclared", "Blocks", "AttackerBlocked", "AttackerUnblocked"):
                for t in vc["combo"]:
                    if "self" not in vc["filters"]: add(main, "trigger_filter:" + t)
                for f in vc["filters"]:
                    if f != "self": add(main, "trigger_filter:" + f)
                for s in vc["scope"]: add(main, "trigger_control:" + s)
            else:
                for t in vc["combo"]: add(main, "trigger_filter:" + t)
            if p.get("ActivationLimit"): add(main, "trigger_limit:%s_per_turn" % p["ActivationLimit"])
            if p.get("CheckSVar") or p.get("IsPresent") or p.get("PlayerTurn") or p.get("Condition"):
                pass
        # ----- static
        if kind == "S" and p.get("Mode") == "Continuous":
            aff = p.get("Affected", "")
            ad = p.get("AffectedDefined", "")
            if "Equipped" in ad: add(main, "affects:equipped")
            elif "Enchanted" in ad: add(main, "affects:enchanted")
            elif "Self" in aff or ad == "Self": add(main, "affects:self")
            elif aff:
                va = valid(aff)
                for t in va["combo"]: add(main, "affects:" + t)
                for c in va["colors"]: add(main, "affects_color:" + c)
                for s in va["scope"]: add(main, "affects_scope:" + s)
                for f in va["filters"]: add(main, "affects_filter:" + f)
            for k in ("AddKeyword", "AddHiddenKeyword"):
                if k in p:
                    for kw in re.split(r"\s*&\s*", p[k]): add(main, "grants:" + tok(kw.split(":")[0]))
            for k, t in (("AddPower", "pump_power"), ("AddToughness", "pump_toughness"), ("SetPower", "set_power"), ("SetToughness", "set_toughness")):
                if k in p: add(main, "%s:%s" % (t, signed(p[k]) if t.startswith("pump") else p[k].lower()))
            if p.get("AddAbility") or p.get("AddTrigger"): add(main, "grants_ability")
            if p.get("Condition") or p.get("CheckSVar"):
                add(main, "condition")
            if p.get("IsPresent"):
                vpz = valid(p["IsPresent"])
                add(main, "condition")
                for t in vpz["combo"]: add(main, "condition_present:" + t)
                for s in vpz["scope"]: add(main, "condition_control:" + s)
                if p.get("PresentZone"): add(main, "condition_zone:" + tok(p["PresentZone"]))
        if kind == "S" and p.get("Mode") == "ReduceCost":
            vcard = valid(p.get("ValidCard", ""))
            for t in vcard["combo"]: add(main, "cost_reduce_type:" + t)
            for c in vcard["colors"]: add(main, "color:" + c)
            if p.get("Amount"): add(main, "cost_reduce_amount:" + (p["Amount"] if p["Amount"].isdigit() else "x"))
        if kind == "S" and p.get("Mode") == "RaiseCost":
            add(main, "cost_raise")
            if p.get("Amount"): add(main, "cost_raise_amount:" + (p["Amount"] if p["Amount"].isdigit() else "x"))
        if kind == "S" and p.get("Mode") in ("CantBlockBy",):
            att = p.get("ValidAttacker", "")
            if "Self" in att or "IsRemembered" in att:
                if p.get("ValidBlocker"):
                    vb = valid(p["ValidBlocker"])
                    add(main, "block_restriction")
                    for t in vb["combo"]: add(main, "block_restriction_type:" + t)
                    for c in vb["colors"]: add(main, "block_restriction_color:" + c)
                    for f in vb["filters"]: add(main, "block_restriction_filter:" + f)
                else: add(main, "unblockable")
        if kind == "S" and p.get("Mode") in ("CantAttack", "CantBlock", "CantBeCast", "CantBeActivated", "CantTarget"): add(main, "restriction:" + snake_words(p["Mode"]))
        # ----- v3 (blind test B round 1): zones, scope, conditions, keyword removal, static costs
        if p.get("Condition"): add(main, "condition_kind:" + tok(p["Condition"]))
        if p.get("PlayerTurn") == "True" and kind in ("S", "T"): add(main, "condition_kind:your_turn")
        for zk in ("EffectZone", "ActivationZone"):
            if p.get(zk) and tok(p[zk]) != "battlefield": add(main, "active_zone:" + tok(p[zk]))
        if kind == "T" and p.get("TriggerZones") and tok(p["TriggerZones"]) not in ("battlefield",): add(main, "active_zone:" + tok(p["TriggerZones"]))
        if kind == "S":
            if p.get("RemoveKeyword"):
                for kw in re.split(r"\s*&\s*", p["RemoveKeyword"]): add(main, "removes:" + tok(kw.split(":")[0]))
            if p.get("CantHaveKeyword"):
                for kw in re.split(r"\s*&\s*", p["CantHaveKeyword"]): add(main, "cant_have:" + tok(kw.split(":")[0]))
            if p.get("RemoveAllAbilities") == "True": add(main, "loses_abilities")
            for key, tg in (("AddAbility", "grants_ability_api"), ("AddTrigger", "grants_trigger")):
                for nm in re.split(r"\s*&\s*", p.get(key, "")):
                    d = sv.get(nm.strip(), "")
                    mm = re.match(r"^(?:AB|SP|DB)\$ (\w+)", d) if key == "AddAbility" else re.search(r"Mode\$ (\w+)", d)
                    if mm: add(main, "%s:%s" % (tg, snake_words(mm.group(1))))
            if p.get("Mode") in ("CantAttackUnless", "CantBlockUnless", "CantBeCast", "CantBeActivated") and p.get("Cost"):
                n, cols, x = cost_mana(p["Cost"])
                add(main, "static_cost_amount:" + ("x" if x and not n else str(n) if n else "other"))
            if p.get("Mode") == "CantBlockBy" and "Self" in p.get("ValidBlocker", ""):
                va = valid(p.get("ValidAttacker", ""))
                add(main, "block_restriction")
                for t in va["combo"]: add(main, "block_only_attacker:" + t)
                for f in va["filters"]: add(main, "block_only_attacker:" + f)
        if kind == "T":
            if p.get("Number"): add(main, "trigger_nth:" + tok(p["Number"]))
            if p.get("CounterType"): add(main, "trigger_counter:" + tok(p["CounterType"]))
            if p.get("FirstTime") == "True": add(main, "trigger_first_time")
            if p.get("ValidBlocker"):
                vb = valid(p["ValidBlocker"])
                add(main, "trigger_blocker:" + ("self" if "self" in vb["filters"] else (vb["combo"] or ["creature"])[0]))
            if p.get("Mode") in ("Discarded", "Drawn", "CounterAdded", "CounterAddedOnce", "LifeGained", "LifeLost", "Sacrificed", "Cycled", "Exploited"):
                for s_ in valid(p.get("ValidCard", ""))["scope"]: add(main, "trigger_control:" + s_)
        # ----- chained abilities
        for ci, b in enumerate(chain(body)):
            gid = main if ci == 0 else "%s.%d" % (main, ci + 1)
            bp = params(b)
            api = (re.match(r"^(?:AB|SP|DB)\$ (\w+)", b) or [0, ""])[1]
            if api in GENERIC_API and api != "Amass": add(gid, GENERIC_API[api])
            if api in ("ChooseColor", "ChooseType", "ChooseCard") and bp.get("Choices"): add(gid, "choose_options:" + tok(bp["Choices"]))
            nm_ = next((k_ for k_, v_ in sv.items() if v_ == b), None)
            if nm_ in dice_range: add(gid, "dice_range:" + tok(dice_range[nm_]))
            if api == "RollDice":
                add(gid, "dice_sides:" + tok(bp.get("Sides", "6")))
                if bp.get("ResultSubAbilities"): add(gid, "dice_results:%d" % len([x for x in bp["ResultSubAbilities"].split(",") if x]))
            if api == "DigUntil":
                vu = valid(bp.get("Valid", ""))
                for t in vu["combo"]: add(gid, "dig_until:" + t)
                for f in vu["filters"]: add(gid, "dig_until_filter:" + f)
                add(gid, "dig_until_count:" + (bp.get("Amount", "1") if bp.get("Amount", "1").isdigit() else "x"))
                for k_, t_ in (("RevealedDestination", "dig_until_rest"), ("FoundDestination", "dig_until_found"), ("RevealedLibraryPosition", "dig_until_rest_pos")):
                    if bp.get(k_): add(gid, "%s:%s" % (t_, tok(bp[k_])))
            if api in ("ChangeZone", "ChangeZoneAll"):
                if bp.get("Destination"): add(gid, "move_to:" + tok(bp["Destination"]))
                if bp.get("Origin") and bp["Origin"] != "Battlefield": add(gid, "move_from:" + tok(bp["Origin"].split(",")[0]))
                if bp.get("LibraryPosition"): add(gid, "library_position:" + ("top" if bp["LibraryPosition"] == "0" else "bottom" if bp["LibraryPosition"].startswith("-") else tok(bp["LibraryPosition"])))
                if bp.get("Duration"): add(gid, "move_duration:" + tok(bp["Duration"]))
                for f in valid(bp.get("ChangeType", ""))["filters"]: add(gid, "move_filter:" + f)
            if api == "PreventDamage" and bp.get("Amount"): add(gid, "prevent_amount:" + (bp["Amount"] if bp["Amount"].isdigit() else tok(bp["Amount"])))
            if api in ("Protection", "ProtectionAll"):
                g_ = bp.get("Gains", "") or bp.get("Choices", "")
                if "Choice" in g_ or bp.get("Choices"): add(gid, "protection_choice")
                if g_: add(gid, "protection_from:" + tok(g_))
            if api in ("Pump", "PumpAll", "Animate", "AnimateAll") and not bp.get("Duration"): add(gid, "duration:eot")
            if bp.get("Duration"): add(gid, "duration_param:" + tok(bp["Duration"]))
            if api == "Token":
                if bp.get("TokenTapped") == "True": add(gid, "token_tapped")
                if bp.get("AttachedTo"): add(gid, "token_attached")
            if ci > 0 and bp.get("Cost") and api not in ("Charm",):
                add(gid, "pay_to_resolve")
                n, cols, x = cost_mana(bp["Cost"])
                if n or x: add(gid, "pay_mana_amount:" + ("x" if x and not n else str(n)))
                for c_ in cols: add(gid, "pay_color:" + c_)
                for t_ in cost_parts(bp["Cost"]): add(gid, "pay_" + t_)
                if re.search(r"(^|\s)T(\s|$)", bp["Cost"]): add(gid, "pay_cost:tap")
            if re.search(r"(^|\s)Q(\s|$)", bp.get("Cost", "")): add(gid, "cost:untap")
            if "Kicked" in b or any("Kicked" in sv.get(x_, "") for x_ in re.findall(r"\b[A-Z]\w*\b", b)): add(gid, "kicked_effect")
            if api in ("Pump", "PumpAll"):
                if "NumAtt" in bp: add(gid, "pump_power:" + signed(bp["NumAtt"]))
                if "NumDef" in bp: add(gid, "pump_toughness:" + signed(bp["NumDef"]))
                if "HIDDEN Unblockable" in bp.get("KW", ""): add(gid, "unblockable")
                for kw in re.split(r"\s*&\s*", bp.get("KW", "")):
                    if kw and not kw.startswith("HIDDEN") and not kw.startswith("Prevent") and "NumAtt" not in kw: add(gid, "grants:" + tok(kw.split(":")[0]))
                if bp.get("KW", "").startswith("HIDDEN") and "Unblockable" not in bp["KW"]: add(gid, "grants:" + tok(bp["KW"].replace("HIDDEN", "").split(":")[0]))
                if "AddAbility" in bp or "AddTrigger" in bp or "Trigger" in bp.get("KW", ""): add(gid, "grants_ability")
                if "SetPower" in bp or "SetToughness" in bp: add(gid, "set_power:" + bp.get("SetPower", "?").lower())
            if api == "Charm":
                ch = [x for x in re.split(r"[ ,]+", bp.get("Choices", "")) if x]
                add(gid, "modal", "modal_options:%d" % len(ch), "modal_choose:" + bp.get("CharmNum", "1").lower())
            if api == "Untap" or api == "UntapAll": add(gid, "untap")
            if api == "Amass":
                add(gid, "amass", "amass_count:" + (bp.get("Num", "1").lower() if bp.get("Num", "1").isdigit() else "x"))
                if bp.get("Type"): add(gid, "amass_type:" + tok(bp["Type"]))
            if api == "Attach": add(gid, "attach")
            if api == "Effect":
                for sname in re.split(r"[ ,]+", bp.get("StaticAbilities", "")):
                    s_ = sv.get(sname, "")
                    if "Mode$ CantBlockBy" in s_ and "Card.IsRemembered" in s_: add(gid, "unblockable")
            if api in ("LoseLife", "GainLife"):
                n = bp.get("LifeAmount", "")
                add(gid, "life_loss" if api == "LoseLife" else "life_gain", ("life_loss_amount:" if api == "LoseLife" else "life_gain_amount:") + (n if n.isdigit() else "x"))
            if api == "Mill": add(gid, "mill_count:" + (bp.get("NumCards", "1") if bp.get("NumCards", "1").isdigit() else "x"))
            if api == "Scry": add(gid, "scry_count:" + (bp.get("ScryNum", "1") if bp.get("ScryNum", "1").isdigit() else "x"))
            if api == "Surveil": add(gid, "surveil_count:" + (bp.get("Amount", "1") if bp.get("Amount", "1").isdigit() else "x"))
            if api == "Dig":
                dn = bp.get("DigNum", "1")
                add(gid, "look_top:" + (dn if dn.isdigit() else "x"))
                if bp.get("ChangeNum"): add(gid, "dig_keep:" + (bp["ChangeNum"] if bp["ChangeNum"].isdigit() else "all" if bp["ChangeNum"] == "All" else "x"))
                if bp.get("DestinationZone"): add(gid, "dig_to:" + tok(bp["DestinationZone"]))
                if bp.get("DestinationZone2"): add(gid, "dig_rest:" + tok(bp["DestinationZone2"]))
                if bp.get("ChangeValid"):
                    for t in valid(bp["ChangeValid"])["combo"]: add(gid, "dig_filter:" + t)
            if api in ("PutCounter", "PutCounterAll", "RemoveCounter", "RemoveCounterAll", "MoveCounter", "Proliferate"):
                cn = bp.get("CounterNum", "1")
                if api != "Proliferate": add(gid, "counter_count:" + (cn if cn.isdigit() else "x"))
                if api.startswith("Remove"): add(gid, "counter_remove")
                if api.endswith("All"): add(gid, "counter_on:each")
                elif bp.get("ValidTgts"): add(gid, "counter_on:target")
                elif bp.get("Defined") in ("Self",) and api in ("PutCounter", "RemoveCounter"): add(gid, "counter_on:self")
            if api == "Animate":
                if "Power" in bp or "Toughness" in bp: add(gid, "becomes_pt:%s/%s" % (bp.get("Power", "?").lower(), bp.get("Toughness", "?").lower()))
                for kw in re.split(r"\s*&\s*", bp.get("Keywords", "")):
                    if kw: add(gid, "becomes_kw:" + tok(kw))
                if bp.get("Duration"): add(gid, "becomes_duration:" + tok(bp["Duration"]))
                else: add(gid, "becomes_duration:eot")
                add(gid, "animate")
            if api == "Sacrifice" and "SacValid" in bp:
                for f in valid(bp["SacValid"])["filters"]:
                    if f in ("token", "nontoken"): add(gid, "sacrifice_filter:" + f)
            if bp.get("ValidTgts"):
                vt = valid(bp["ValidTgts"])
                for f in vt["filters"]:
                    if f not in ("other", "self"): add(gid, "target_filter:" + f)
                for c in vt["colors"]: add(gid, "target_color:" + c)
                if "ValidTgts" in bp and api in ("Pump", "PumpAll", "Animate") and not ("NumAtt" in bp or "NumDef" in bp): add(gid, "grant_single")
            # who is affected: player scope of the effect
            if api in ("LoseLife", "GainLife", "Discard", "Draw", "Mill", "DealDamage", "Scry", "Surveil", "Sacrifice", "GainControl", "Dig", "Token", "Reveal", "RevealHand", "SetLife", "Poison", "AddTurn"):
                pdf = bp.get("Defined") or bp.get("TokenOwner") or ""
                pl = player_of(pdf) if pdf else ""
                if bp.get("ValidTgts") and ("Player" in bp["ValidTgts"] or "Opponent" in bp["ValidTgts"] or "Any" in bp["ValidTgts"]): pl = pl or "target"
                if api in ("Draw", "GainLife", "Scry", "Surveil", "Dig", "Token") and not pl: pl = "you"
                if pl: add(gid, "effect_player:" + pl)
            # optional / pay
            if bp.get("OptionalDecider") or bp.get("Optional") == "True" or "UnlessCost" in bp or bp.get("OptionalCost"):
                add(gid, "optional")
            if "UnlessCost" in bp:
                n, cols, x = cost_mana(bp["UnlessCost"])
                add(gid, "unless_pays", "unless_cost_amount:" + ("x" if x and not n else str(n) if (n or x) else "other"))
                if "UnlessPayer" in bp: add(gid, "unless_payer:" + (player_of(bp["UnlessPayer"]) or tok(bp["UnlessPayer"])))
            if api in ("ImmediateTrigger", "DelayedTrigger"):
                add(gid, "reflexive" if api == "ImmediateTrigger" else "delayed")
                if bp.get("UnlessCost") or bp.get("Cost"):
                    n, cols, x = cost_mana(bp.get("UnlessCost") or bp.get("Cost"))
                    add(gid, "reflexive_cost_amount:" + ("x" if x and not n else str(n)))
                    for t in cost_parts(bp.get("UnlessCost") or bp.get("Cost")): add(gid, t)
            if bp.get("ActivationLimit") and ci > 0: add(gid, "limit_per_turn:" + bp["ActivationLimit"])
            # conditions on this part
            for key in ("PresentCompare", "ConditionCompare", "SVarCompare", "ConditionSVarCompare", "ConditionPresentCompare"):
                mc = re.match(r"^(GE|LE|EQ|GT|LT|NE)(\w+)$", bp.get(key, ""))
                if mc: add(gid, "condition_compare:%s_%s" % (mc.group(1).lower(), mc.group(2).lower()))
            for key in ("IsPresent", "ConditionPresent"):
                if key in bp:
                    add(gid, "condition")
                    vpz = valid(bp[key])
                    for f in vpz["filters"]: add(gid, "condition_filter:" + f)
                    add(gid, "condition_valid:" + tok(bp[key]))
                    for t in vpz["combo"]: add(gid, "condition_present:" + t)
                    for s in vpz["scope"]: add(gid, "condition_control:" + s)
                    if bp.get("PresentZone") or bp.get("ConditionZone"): add(gid, "condition_zone:" + tok(bp.get("PresentZone") or bp.get("ConditionZone")))
            for key in ("CheckSVar", "ConditionCheckSVar"):
                if key in bp:
                    add(gid, "condition")
                    d = sv.get(bp[key], "")
                    if "$" in d: add(gid, "condition_check:" + snake_words(d.split("$")[-1]))
            if bp.get("ConditionManaSpent") or bp.get("Adamant"): add(gid, "condition_mana_spent:" + tok(bp.get("ConditionManaSpent") or bp.get("Adamant")))
            if bp.get("ConditionCheckSVar") is None and bp.get("ConditionDefined") and not bp.get("ConditionPresent"): add(gid, "condition")
            if bp.get("Threshold") == "True" or "Threshold" in bp: add(gid, "condition_threshold")
            for t in x_def(sv, [b]): add(gid, t)
    return {g: list(dict.fromkeys(t)) for g, t in groups.items() if t}


def chapter_lines(lines, sv):
    """Saga chapters: K:Chapter:<n>:<SVar>,<SVar>[:<chapters>...] -> {chapter number: [synthetic 'A:' lines]} so the same tagger can read each chapter's effects"""
    out = {}
    for l in lines:
        m = re.match(r"^K:Chapter:(\d+):([^:]*)(?::(.*))?$", l)
        if not m: continue
        names = [x for x in m.group(2).split(",") if x]
        for i, nm in enumerate(names, 1):          # K:Chapter:<count>:<SVar for chapter I>,<SVar for chapter II>,...
            if nm in sv:
                out.setdefault(i, []).append("A:" + sv[nm])
    return out
