# usage: python blind_analyse.py KEY_DIR GRADE_DIR LABEL GAP [GAP ...]  - prints sample cards (Oracle, tags, grader note) per gap label, for clustering fixes
import json,glob,sys,collections,random
kd,gd,label=sys.argv[1],sys.argv[2],sys.argv[3]
K={}
for k in glob.glob(kd+'/key_*.json'):
    for c in json.load(open(k,encoding='utf-8')):K[c['id']]=c
G={}
for f in glob.glob(gd+'/grade_*.tsv'):
    for l in open(f,encoding='utf-8'):
        p=l.rstrip('\n').split('\t')
        if p[0] in K and len(p)>=5:G[p[0]]=p
random.seed(1)
by=collections.defaultdict(list)
for i,p in G.items():
    for g in p[2].split(';'):
        g=g.strip()
        if g and g!='-' : by[g].append(i)
for g in sys.argv[4:]:
    ids=by[g];random.shuffle(ids)
    print('=====',g,len(ids))
    for i in ids[:9]:
        c=K[i];p=G[i]
        print(c['name'],'|',c['oracle'][:260],'\n   TAGS:',' '.join(c['tags'])[:300],'\n   NOTE:',p[1],p[4])
