# deck-balance-lab reply (read-only; no sim, suite or setup run). Data read: TIER1_TAGS.toon tag counts, A_summary.md, TAG_LINKS.md.
Tag counts over 2131 tier 1 cards: creature 1649, flying kw 190, enchantment 190, artifact 186, instant 158, sorcery 126, mana_source 117, discard 99, haste 41, tutor 34, bounce 27 (remove:bounce 28), steal 18, remove:destroy 31, remove:exile 12, draw 462 (tempo:+0.5 475, tempo:+1 383, tempo:+2 34), counters_plus 213.

## 1 ANALYSIS
analysis[6]{topic|finding}:
 speed|Proxy per deck: sum of haste/kw:haste, cost_generic:0-2 cards, mana_source count, tutor, tempo:+n. Early-curve + ramp gives a speed index; T1 tag counts of haste (41) and fast mana are low, so speed differences come mostly from curve (cost_generic), not tags
 interaction|remove:destroy 31 / exile 12 / bounce 28 / steal 18 across 2131 cards = removal is rare in T1. Per-deck removal density (count of remove:* + counter-spell tags) likely separates over/under-performers: decks with 0-2 removal lose to fast boards
 card_advantage|draw (462) + tempo sum per deck = card-advantage score; discard (99) and mill (24) are opponent-side or self-side and must be split by effect_player
 evasion|kw:flying 190, trample 51, menace 25, plus evasion tag 32: evasion share decides unblocked damage; ai blocks poorly, so evasion-heavy decks may overperform vs ground decks
 archetype_cells|Tag profile (creature share, scales:Y/lord:Y, kw cluster, cardtype mix) can define cells beyond the declared archetype: e.g. flyers, counters (counters_plus 213), tokens, equipment (kw:equip 32), discard
 matchup_groups|Group by evasion vs ground-only, removal-rich vs none, ramp vs no-ramp; a matchup matrix over these 3 binary axes is 8 cells, far fewer than archetype pairs, so fewer games per cell

## 2 UTILITY (balance-lab scope)
utility[5]{use|tags}:
 stratify_sample|per-deck vectors from creature share, mana_source, remove:*, evasion/kw:flying, haste, tempo sum; sample games across vector quantiles instead of declared archetype only
 explain_outliers|correlate deck win rate with removal count, evasion count, mana_source, avg cost_generic, tutor, draw tempo; outlier decks with high tag score but low win = AI misplay cards (flag via forge_ai AILogic field)
 group_by_profile|k-means or rule bins on above; report win rate per bin with intervals (H28 counts)
 starter_vs_ai|compute the same vector for the 10 starters (STARTER_TAGS) so the PC deck sits in the same space as the AI deck it fights
 stop_rule|adaptive stopping per bin (cheaper than per deck)

## 3 SUGGESTIONS
suggestions[7]{id|finding|suggestion|why}:
 S1|no explicit removal-class tag family: remove:destroy/exile/bounce exist but only 31/12/28; sweepers (wrath) and counterspells not visible|add removal_target:creature|any and sweeper (affects all) and counterspell tags; check names like Doom Blade, Wrath of God|removal density is the main balance axis
 S2|no mana-value tag; cost_generic:n exists but colored symbols are separate|add num:mv (total) per card|curve/speed index needs mv per card
 S3|fast mana (Sol Ring-type) not distinct from mana_source (117)|add fast_mana (mana_source with cost<=2 and net positive)|speed proxy; H10 near-staple rocks
 S4|discard and mill: effect_player not always set (Armix has effect_player:you)|require effect_player on every discard/mill/draw|opponent-side vs self-side cannot be split otherwise
 S5|evasion tag is a loose bucket (evasion 32) beside kw:flying 190|add evasion:flying|menace|trample|unblockable consistently (also granted evasion)|evasion share is a matchup axis
 S6|AI-weak cards invisible: forge_ai: AILogic=- on many cards|tag cards whose AILogic is missing or listed in AI_FLAGGED_CARDS as ai_risk|explain outlier decks that underperform because AI misplays
 S7|tempo:+n sums need a per-deck total, not per card|ask main for a deck-level summary file (deck x tag counts, TOON) built from the tagger|input for stratification; blind test A shows AMOUNT/TRIGGER_CONDITION gaps (151/126 cards), so treat amounts as approximate
