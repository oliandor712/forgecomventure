# Blind tag test, sample A (1000 tier 1 cards, seed 20261022)

Method: each card reduced to its tags and linked groups (no name, no Oracle text); 10 readers (one per 100 cards, no tools beyond one Read of the rules, one of the input and one Write) rebuilt the rules text with `?` placeholders for anything the tags do not state; 10 graders compared with the lossless Oracle text (verdict, gap labels, wrong tags). Tools: `blind_test.py`, `blind_reader_prompt.md`, `blind_grader_prompt.md`. Cards: tier 1 decks (staged + live), no basic lands, only cards carrying an ability tag.

| Round | Faithful | Mostly | Partial | Wrong |
|---|---|---|---|---|
| 1 (tagger after the gap pass v1) | 355 | 442 | 199 | 4 |
| 2 (after gap pass v2, same cards) | 441 | 439 | 118 | 2 |

Grades: `A_r1_grades.tsv`, `A_r2_grades.tsv` (id, verdict, gaps, wrong tags, note; ids map to cards in the key files kept outside the repo under `%TEMP%\tagtest_keys`).

Top gaps after round 2 (cards): AMOUNT 151, TRIGGER_CONDITION 126, FILTER 80, COST 80, ZONE 78, GRANT_SCOPE 71, TRIGGER_FILTER 56, MODE 53, KEYWORD 35, TOKEN 32, DURATION 26, TIMING 18, EVASION 12.
Most frequent wrong tags after round 2: cost_mana_amount (read as generic cost; now split into cost_generic and cost_symbols), trigger_scope:self on "this or another X" triggers (now trigger_scope:self_or_other), dig_rest and counter_on defaults (removed), sorcery_speed on token reminder text (restricted to the card's own ability), `cleanup` (internal housekeeping, no longer tagged).

Caveats: round 2 reuses round 1's cards, so it is flattered by fixes written from them; the graders were stricter than in the 20-card test; readers and graders are language models and the verdicts are one pass; the 6:30 AM sample B run (different 1000 cards) is the unseen check. One reader-count anomaly: in round 1 each reader reported 3 tool calls instead of 2 (cause not visible); in round 2, 4 calls against a limit of 3 (rules read, input read, output write) with one more unexplained.
