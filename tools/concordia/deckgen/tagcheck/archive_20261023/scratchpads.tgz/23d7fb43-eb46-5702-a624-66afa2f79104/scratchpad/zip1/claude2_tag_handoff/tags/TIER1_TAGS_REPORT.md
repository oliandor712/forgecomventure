# Tier 1 tagging run: report

staged decks 80, live decks 80; 2131 distinct cards (775 in both sets), 2131 tagged, 0 with no script (none).

## Most common tags

cardtype:creature 1649, effect_player:you 699, target_count:one 511, type:human 498, trigger:etb 489, trigger_scope:self 472, target_type:creature 460, token_make 412, duration:eot 390, cost:mana 297, token_count:1 281, tempo:+0.5 234, supertype:legendary 231, target_scope:you_control 213, counters_plus 213, condition 203, tempo:+1 191, draw 190, kw:flying 190, cardtype:enchantment 190, cardtype:artifact 186, cost:tap 181, counter_count:1 175, trigger_player:you 173, pump_power:+1 168, counter:p1p1 166, token_color:colorless 165, cardtype:instant 158, token_cardtype:artifact 155, sacrifice_outlet 154, draw_count:1 150, token_pt:1/1 150, optional 145, lifegain 144, trigger_control:you_control 142, cost:sacrifice 131, type:warrior 129, cardtype:sorcery 126, cost_sacrifice_amount:1 124, trigger:attacks 118, move_from:graveyard 118, trigger:dies 118, trigger_zone:graveyard 118, mana_source 117, trigger_scope:other 116, type:rogue 113, artifact_token 112, pump_toughness:+1 110, move_to:hand 108, life_gain 101

## Trigger types seen in clauses

activated 481, etb_self 418, static 408, spell 283, attacks 110, phase 94, dies_self 84, spell_cast 84, etb_other 70, combat_damage 51, dies_other 36, replacement 35, gain_life 13, leaves_self 12, draws 12, blocked 9, changeszoneall 9, discarded 8, mutates 8, taps 7, damage 7, counteraddedonce 7, sacrificed 7, attackersdeclared 7, cycled 5, discardedall 4, damagedoneonce 4, attackersdeclaredonetarget 4, attackerunblocked 3, blocks 3

## Most common verbs (script API)

token 297, static_continuous 272, pump 212, putcounter 146, changezone 128, draw 108, dealdamage 61, gainlife 50, pumpall 48, static_cantblockby 44, static_reducecost 39, mana 37, discard 37, dig 31, mill 29, effect 28, untap 25, loselife+gainlife 24, destroy 24, regenerate 24, charm 22, loselife 22, scry 19, animate 17, sacrifice 16, replace_moved 15, immediatetrigger 13, setstate 13, tap 13, surveil 11

## Cards with no ability tag beyond type, keyword and cost tags (107)

Hovermyr, Darksteel Myr, Shimmer Myr, Frogmite, Skeletal Snake, Nyxborn Marauder, Servant of Nefarox, Branchblight Stalker, Elvish Warrior, Nissa's Chosen, Thornweald Archer, Earthbending Lesson, Fang of Shigeki, Balduvian Bears, Bear Cub, Forest Bear, Grizzly Bears, Runeclaw Bear, Alpine Grizzly, Canopy Spider, Deadly Recluse, Grappler Spider, Juvenile Gloomwidow, Sporecap Spider, Blightwidow, Giant Spider, The Fabulous Frog-Man, Bounding Wolf, Sacred Wolf, Pouncing Cheetah, Ferocious Zheng, Stalking Tiger, Gorilla Berserkers, Satyr Rambler, Nyxborn Brute, Black Widow, Natasha Romanoff, Quicksilver, Pietro Maximoff, The Whizzer, Classic Speedster, Hulk, Bruce Banner, Boarding Party, Incurable Ogre, Flying Men, Aegis Turtle, Riptide Turtle, Talas Scout, Iguana Parrot, Flying Dolphin-Fish, Ancient Carp, Renari, Merchant of Marvels, Memory Guardian, Field Creeper, Kolinahr Priest, Whirlwind Adept, Mahamoti Djinn, Fencing Ace, Armored Warhorse, Jötun Grunt, Lucent Liminid, Suntail Hawk, Lantern Kami, Dancing Scimitar, Aven Skirmisher, Savannah Lions, Serra Angel, Mothrider Samurai, Nath's Buffoon, Gloom Pangolin, Hired Poisoner, Hand of Silumgar, Pestilent Syphoner, Plague Stinger, Walking Corpse, Typhoid Rats, Rancid Rats, Brushstrider, Jibbirik Omnivore, Cystbearer, Swordwise Centaur, Glistener Elf, Ashcoat Bear, Woodland Changeling, Woodland Druid, Terrain Elemental, Root Sliver, Swab Goblin, Raging Goblin, Goblin Assailant, Tomik, Izzet Sparkmage, Breakneck Berserker, Aven Envoy, Bay Falcon, Sea Eagle, Storm Crow, Zephyr Falcon, Curio Vendor, Pixie Guide, Mtenda Herder, Cliffhaven Sell-Sword, Makindi Aeronaut, Skyhunter Skirmisher, Loxodon Line Breaker, Loxodon Wayfarer, Loxodon Partisan, Valiant Guard, Aven Squire, Sokka, Wolf Cove's Protector, Battlefield Raptor

## mtgish second-opinion flags

not in mtgish: 20 (Nezumi Graverobber, Blackbloom Rogue, Catapult Fodder, Bala Ged Recovery, Hermit of the Natterknolls, Tireless Hauler, Reckless Waif, Village Messenger, Breakneck Rider, Geier Reach Bandit, Song-Mad Treachery, Silundi Vision, Hydroelectric Specimen, Ambitious Farmhand, Panicked Bystander, Bereaved Survivor, Heir of Falkenrath, Duskwatch Recruiter, Daring Sleuth, Skyclave Cleric)

script has more abilities than mtgish rules: 8 (Citadel of Pain, Case of the Shattered Pact, Slippery Scoundrel, Mistfire Weaver, Caterwauling Boggart, Skywatcher Adept, Hada Spy Patrol, Nightwhorl Hermit)
