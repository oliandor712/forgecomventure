import os, re, json, shutil, glob
R = os.path.expanduser('~/tagcheck_runs'); G = '/home/user/forgecomventure/tools/concordia/deckgen/tags/'
full = open(G + 'READER_GRAMMAR.md').read()
full = full[full.index('## 1. Procedure'):full.index('## 8. What this draft')].strip()
short = open(G + 'READER_GRAMMAR_SHORT.md').read()
short = short[short.index('1. Card itself'):].strip()
FMT = ('OUTPUT FORMAT FOR THIS RUN (records): for every card write `records`: a list with one entry per ability, in output order: '
       '{"group":"k1|c1|...","kind":"keyword|triggered|activated|static|spell","text":"..."}; one record per ability (a group with its sub-groups is one record). '
       'Also write `text` = the record texts joined with " / ". Everything else in the entry as usual (id, unclear, conflicts, recognised).')
arms = {'c1': ('GRAMMAR (full)', full, None), 'c2': ('GRAMMAR (full)', full, FMT), 'c3': ('GRAMMAR (short)', short, None)}
for arm, (title, g, fmt) in arms.items():
    for r in 'abc':
        run = 'r13%s%s' % (arm, r); wd = os.path.join(R, run)
        if os.path.exists(wd): shutil.rmtree(wd)
        os.makedirs(wd + '/out'); shutil.copytree(R + '/r12a/in', wd + '/in'); shutil.copytree(R + '/r12a/key', wd + '/key')
        for f in glob.glob(wd + '/in/reminders_*.json'):
            d = json.load(open(f)); d['reader_grammar'] = g
            if fmt: d['output_format'] = fmt
            json.dump(d, open(f, 'w'), indent=1)
print(len(full.split()), len(short.split()))
