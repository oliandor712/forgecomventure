# learning_data/tag_to_text_pairs.jsonl

One JSON object per card per test round. Fields: round, round_note, id, card, oracle_text (lossless Oracle text of every face from the Forge script), tags (flat list from the tagger of that round), groups (which tags came from the same printed ability), reader_rebuild (text rebuilt blind from tags only, `?` = not stated), reader_unspecified, grade (verdict FAITHFUL/MOSTLY/PARTIAL/WRONG, gaps, wrong_tags, note; null where not graded).
Rows per round: {"A_r1": 1000, "A_r2": 1000, "B_r1": 1000, "B_r2": 1000}.
Use: (1) train or prompt a reader that maps tags to rules text; (2) find which tag patterns lose which facts (gap labels); (3) evaluate a new tagger by rebuilding the same cards; (4) the same card appears in A_r1 and A_r2 (and B_r1 and B_r2) under different tagger versions, so you can diff tags against grades.
Caveats: grades come from a language-model grader in one pass; A_r2 is flattered because fixes were written from the same cards; B_r1 is the unseen baseline. The key files were never shown to the readers. Oracle text is reproduced from the Forge card scripts for the user's own use.
