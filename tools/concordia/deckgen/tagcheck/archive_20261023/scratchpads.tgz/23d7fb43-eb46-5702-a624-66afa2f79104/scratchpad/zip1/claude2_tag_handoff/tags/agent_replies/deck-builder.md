# deck-builder reply: tag analysis (H55 hold; read-only; sampled TIER1_TAGS.toon, 2131 cards, plus blind A_summary)

## 1 analysis
analysis[6|]{area|tags beat ability_tags.py|tags fall short}:
  card identity|per-card supertype/cardtype/type/landtype/kw ordered (H52); full type counts for H11 creature bands and H48 permanents-only counts, no Oracle regex|none noted
  scaling/potential (H46/H47)|scales:X, x_def:*, lord:, token_type/token_count/token_pt give potential stat and token counts directly|x_def is a raw Forge string (valid_artifact_you_ctrl_plus_y); needs a normaliser to type counts
  commander support (H17, 5 needed)|trigger:*, trigger_scope, trigger_filter, condition, counter:*, affects/grants give structured triggers (etb self vs other H38, attacks, upkeep) instead of text regex|trigger_scope:self_or_other newly split; old rows may predate it
  role quotas|draw (190), tutor (34), damage (71), recursion/reanimate, mill, bounce (27), mana_source (117) usable|NO removal/ramp/sweeper/protection-role tags: removal=3 tags, ramp=0, board_wipe=0, destroy/exile-target not tagged as a verb. Role quotas still need ability_tags/build.py regex
  archetype fit|tempo:+n, token_make, evasion, landfall, sacrifice_outlet (154), recursion, counter:* give density counts per archetype|no archetype or role summary tag; needs derived layer
  accuracy|blind r2: 441 faithful, 439 mostly, 118 partial, 2 wrong of 1000 (r2 flattered, same cards)|top gaps AMOUNT 151, TRIGGER_CONDITION 126, FILTER 80, COST 80, ZONE 78, GRANT_SCOPE 71: filters ("nonland", "with flying") are the ones synergy counts need

## 2 utility
uses[7|]{use|query|tags}:
  creature band H11|count cardtype:creature per deck, split by type:*|cardtype:creature
  commander support H17|count deck cards sharing commander's trigger/payload pair|trigger:*, trigger_filter, affects, scales:*, lord:*, kw:*
  tribal/potential H32/H47|deck count of type:X vs commander lord:X / scales:X|type:*, lord:*, scales:*
  token decks|sum token_make cards, token_type, token_count|token_make, token_type:*, token_count, token_pt
  land-type H45|landtype:X counts vs commander landtype need|landtype:*
  reach/evasion for archetype|evasion + evasion_grant + kw:flying/trample count|evasion, evasion_grant
  protection/hate pool|protection_trick, hexproof, indestructible, grave_hate lists|protection_trick, indestructible

## 3 suggestions
suggestions[7|]{id|finding|suggestion|why}:
  D1|No removal tag (removal=3, destroy/exile-target not tagged; e.g. Swords-type effects)|derive role:removal = verb destroy/exile/damage/bounce/-x with target_type creature|ability_tags has this, role quotas need it
  D2|No ramp tag (ramp=0) though mana_source exists (117) and land_tutor (24)|role:ramp = mana_source non-land + land_tutor + put_land (e.g. Rampant Growth, Sol Ring)|ramp caps per tier
  D3|No sweeper/wipe tag (0)|role:sweeper = destroy/damage all creatures|control archetype, curve
  D4|x_def values are raw Forge strings|normalise to scales:<type> plus a count rule|H46/H47 needs type counts
  D5|filter gaps (80 cards, FILTER) hide nonland/with-flying qualifiers|always tag trigger_filter / target_filter incl. nonX|commander support false positives
  D6|duration tags only 355; "gains X until end of turn" rows may lack scope|check pump rows w/o duration:eot (H51)|combat-trick vs permanent buff
  D7|Armix has x_def + scales:artifact + scales:graveyard but no support-tag form for discard->artifact count|add synergy:discard_outlet / makes_graveyard|H44 cluster Oin
