# Blind grader prompt (copy into an Agent call; replace {KEY}, {RECON}, {OUT}, {N})

Use a general-purpose subagent, model sonnet, effort low, one per batch, after its reader has finished. The grader may read the key (lossless Oracle text) and the reader's reconstruction.

```
You grade a blind test. A reader rebuilt each Magic card's rules text from machine tags only (no names, no Oracle text, no outside knowledge). Compare each reconstruction with the lossless Oracle text.
Files (use Read only, then ONE Write; no other tools, no searching):
- Key (JSON list; fields id, name, tags, oracle): {KEY}
- Reader output (lines `ID | abilities | UNSPECIFIED: ...`): {RECON}
Write a tab-separated file {OUT} with one line per card id, columns:
id <TAB> verdict <TAB> gaps <TAB> wrong_tags <TAB> note
- verdict: FAITHFUL = every printed ability is present and correct, and ? placeholders cover only details that really are unimportant; MOSTLY = all abilities found but one important fact is missing or wrong (number, cost, target, condition, who is affected); PARTIAL = an ability is missing or half wrong; WRONG = the main effect is wrong or invented.
- gaps: semicolon-separated labels for facts the tags failed to give, from this list: AMOUNT (numbers, costs, X values), GRANT_SCOPE (who a static effect or keyword grant applies to), TRIGGER_CONDITION (if/as long as/intervening if), TRIGGER_FILTER (what kind of permanent/spell/player a trigger watches), TIMING (phase or turn timing), EVASION (can't be blocked/restrictions), MODE (modal/choose/optional "may"), FILTER (target or sacrifice filters such as nontoken, power limits), ZONE (which zone), DURATION, COST (activation or additional costs), TOKEN (token details), KEYWORD (keyword details), ALTFACE (second face/adventure), OTHER:<three words>. Use - if none.
- wrong_tags: tags that stated something false or misleading (copy the tag text), or - if none.
- note: at most 12 words.
Be strict and consistent. Reply with ONLY: `graded {N} <lines written>`.
```
