# Blind tag test: 20 tier 1 cards (2026-10-22)

Method: 20 random cards from the tier 1 decks (none shown to the user earlier), each reduced to its tag list and linked groups (no name, no Oracle text, no sprite or deck data). A subagent with no tool access reconstructed each card's rules text from the tags alone. The lossless Oracle line from the Forge script was compared afterwards. Grades are the main session's judgement.

Result: 7 match, 4 mostly right, 4 partial, 5 wrong.

| # | Card | Grade | What the tags lost |
|---|---|---|---|
| 1 | Sheoldred's Edict | partial | modal "choose one"; nontoken vs token creature filter; "each opponent" |
| 2 | Beastrider Vanguard | partial | mana amount {4}{G}; look at top three; reveal a permanent; rest to the bottom |
| 3 | Adelbert Steiner | match | (extra `lifegain` tag duplicates `kw:lifelink`) |
| 4 | Fire Sages | match | activation cost {1}{R}{R}; firebending mana colour |
| 5 | Mycosynth Wellspring | mostly right | the "put into a graveyard" trigger has no effect tags of its own (same search as the enter trigger); "may" |
| 6 | White Sun's Zenith | match | exact |
| 7 | Abzan Beastmaster | wrong | upkeep trigger and the greatest-toughness condition are untagged; read as an enter trigger |
| 8 | Silvergill Adept | match | the reveal-a-Merfolk-or-pay-{3} cost (only `forge_line:alternateadditionalcost`) |
| 9 | Beamtown Beatstick | mostly right | +1/+0 bonus; trigger is combat damage to a player |
| 10 | Keskit, the Flesh Sculptor | mostly right | sacrifice three other artifacts and/or creatures (tag says artifact only); top three, two to hand |
| 11 | Dwarven Warriors | wrong | the effect is "can't be blocked" for power 2 or less; no evasion or restriction tag |
| 12 | Ronin Warclub | mostly right | +2/+1 bonus; the trigger attaches the equipment |
| 13 | Bloodmark Mentor | wrong | grants first strike to red creatures you control; tag reads as the card's own first strike |
| 14 | Mycologist | match | amounts only |
| 15 | Boon of Boseiju | partial | X = greatest mana value among your permanents; untap it |
| 16 | Arterial Flow | partial | "if you control a Vampire" condition; opponents lose life, you gain life |
| 17 | Prowling Felidar | wrong | landfall: trigger is a land entering, tag has no land filter |
| 18 | Bothersome Noisemaker | wrong | trigger is a noncreature spell but the tag says `trigger_filter:creature`; amass Goblins untagged |
| 19 | Undercity Dire Rat | match | exact |
| 20 | Living Library | match | activation cost {6}; shuffled, not put on top |

## Gaps seen (candidates for new tags, all proposed only)
1. **Amounts lost:** mana costs, pump values and X definitions are not tagged (`cost:mana` has no amount; +1/+0 and +2/+1 do not appear).
2. **Who a static grant applies to:** a keyword granted to other creatures (13) looks the same as the card's own keyword. `affects:` exists but was not emitted here.
3. **Phase triggers and conditions:** upkeep triggers and "if you control ..." conditions (7, 16) are untagged.
4. **Trigger filters:** a landfall trigger shows no land filter (17); a noncreature-spell trigger is tagged `creature` (18), which looks like a tag bug.
5. **Evasion and restriction effects:** "can't be blocked" (11) has no tag.
6. **Modes and filters:** modal choose-one (1), token vs nontoken, untap (15) and amass (18) are untagged.
7. **Combat-damage triggers** on equipped creatures (9) are untagged.
