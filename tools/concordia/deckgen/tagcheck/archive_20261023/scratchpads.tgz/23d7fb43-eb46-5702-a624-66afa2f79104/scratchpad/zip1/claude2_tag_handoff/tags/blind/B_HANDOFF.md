# Sample B handoff and learning data (paused 2026-10-22, scheduled task `tag-blind-test-sample-b`)

Worktree `C:\Users\olian\forgecomventure-claude2`, branch `cd/claude2`. Nothing pushed. H55 stays on. This file is both a resume guide and a record of what the run taught.

## State
| Step | Status |
|---|---|
| 1 build B1 (1000 cards, seed 20261023, excludes sample A) | done; keys `%TEMP%\tagtest_keys\B_r1`, batches `%TEMP%\tagtest_B\blind_r1` |
| 2 round 1 readers (10) and graders (10), score | done; grades saved as `B_r1_grades.tsv` |
| 3 tagger fixes, regenerate | done (committed with this handoff); 51 new proposed families (list below) |
| 4 round 2: build B2 (`--same-as`), readers | done; recon in `%TEMP%\tagtest_B\recon_r2` (10 x 100 lines); keys `%TEMP%\tagtest_keys\B_r2`, batches `blind_r2` |
| 4 round 2 graders | NOT done: the 10 graders were stopped on request before finishing; `grade_r2` is empty. Rerun them, then `blind_test.py score` |
| 5 B_r2_grades.tsv, B_summary.md | not written |
| 6 MASTER_BLIND_TEST.md, two Claude Docs, OUTDATED_DOCS.md, rename of the two old docs | not done |
| 7 agent deployment and AGENT_TAG_REPORT.md | not done; `SendMessage` cannot reach the three sessions ("session nobody opened in this app"); the `mcp__ccd_session_mgmt__send_message` tool is the route to try, otherwise skip and say so |
| 8 final report | not done |

## Results so far
Sample B round 1 (tagger as committed after sample A round 2): FAITHFUL 455, MOSTLY 421, PARTIAL 123, WRONG 1 (A round 1 was 355/442/199/4; A round 2 441/439/118/2). Sample B is unseen cards, so 455 is the honest baseline; A round 2 (441) was flattered by fixes written from the same cards.
Gaps (cards): AMOUNT 136, TRIGGER_CONDITION 104, GRANT_SCOPE 79, COST 69, ZONE 67, FILTER 66, TRIGGER_FILTER 43, MODE 40, KEYWORD 37, TOKEN 31, DURATION 29, TIMING 11, EVASION 9, ALTFACE 4, plus about 35 single OTHER labels (prevent damage, reveal until, dice outcomes, loses abilities, move counters ...).
Wrong tags: lifegain 5 (Food token reminder text), restrict 4, trigger:attackerblocked 4, cost_sacrifice_target:creature 4 and artifact_creature 2, target_count:all 3, effect_player 4, trigger_player:each 2, token_color:blue 2, trigger_filter:creature 2, trigger_source:emblem 2.

## What the gaps turned out to be (cluster, Forge-syntax cause, fix)
| Cluster | Cause in the script syntax | Fix (tag) |
|---|---|---|
| "N or more / at most N" lost (threshold, graveyard count, hand size) | `PresentCompare$`, `SVarCompare$`, `ConditionCompare$` ignored | `condition_compare:ge_5` |
| "creature with power 4 or greater" lost | valid-string filters (`powerGE4`) were not copied into the condition | `condition_filter`, `condition_valid` |
| keyword costs unreadable (kicker, reinforce, transmute, outlast, surge, warp, typecycling, cumulative upkeep ...) | `K:Name:cost` cost part dropped | `kw_cost:name:2g` |
| "you may pay X. If you do ..." | cost lives on the chained sub-ability (`AB$ ... Cost$`), not read | `pay_to_resolve`, `pay_mana_amount`, `pay_cost:*` |
| "return it to your hand", "put on top" | `ChangeZone` Destination/Origin/LibraryPosition ignored | `move_to`, `move_from`, `library_position` |
| reveal until a land | `DigUntil` not read | `dig_until:*` |
| d20 outcome tables | `RollDice ResultSubAbilities$ 1-9:Name` not followed | `dice_sides`, `dice_results`, `dice_range` |
| "while in your graveyard", "during your turn" | `EffectZone$`, `TriggerZones$`, `Condition$ PlayerTurn` ignored | `active_zone`, `condition_kind` |
| "creatures lose flying and can't gain it" | `RemoveKeyword$`, `CantHaveKeyword$` ignored | `removes`, `cant_have`, `loses_abilities` |
| granted abilities with no content | `AddAbility$`/`AddTrigger$` only tagged `grants_ability` | `grants_ability_api`, `grants_trigger` |
| "can't attack unless pays {2}" | static `Cost$` ignored | `static_cost_amount` |
| "can block only creatures with flying" | `CantBlockBy` with Self as blocker | `block_only_attacker` |
| X defined by something other than `Count$` (hand size minus 4, triggered card power) | `SVar:X:TriggeredPlayer$CardsInHand/Minus.4` | `x_def`, `x_scope`, `x_mod` |
| "second card each turn", "first time each turn", counter type watched | `Number$`, `FirstTime$`, `CounterType$` on triggers | `trigger_nth`, `trigger_first_time`, `trigger_counter` |
| "whenever X blocks a creature" read as any creature attacking | `ValidBlocker$` ignored; self-attack trigger tagged `trigger_filter:creature` | `trigger_blocker:self`; the self filter is no longer tagged |
| tapped tokens, Role tokens | `TokenTapped$`, `AttachedTo$` | `token_tapped`, `token_attached` |
| protection from a colour of your choice, prevent N damage | `Protection Gains$ Choice`, `PreventDamage Amount$` | `protection_choice`, `protection_from`, `prevent_amount` |
| "until end of turn" not stated on grants and unblockable | `Pump` without `Duration$` | `duration:eot` default; `duration_param` otherwise |
| `mana_amount:1` for `Produced$ G G` | symbol count ignored | amount = number of produced symbols |
| `cost_sacrifice_target:artifact_creature` | `Artifact;Creature.Other` is OR, `.Other` is a filter | one target tag per alternative plus `cost_sacrifice_filter:other` |
| `lifegain` on cards that only make a Food token | token-type provides rule | now `token_gives_lifegain` (behaviour change: card-level `lifegain` no longer comes from Food tokens; needs approval) |

Still open after these fixes (not attempted): Eternalize/Embalm effect text, Role token effects, Saga token abilities, "choose two different counters" replacement choices, Exhaust, Strive per-target cost, the "doesn't untap" replacement, `restrict` wrong-tag reports (4), `trigger_source:emblem` reading for opponent sources, `effect_player` mistakes on conditional lines.

## New proposed families (51, none approved yet; log them in NEW_TAGS_FOR_APPROVAL.md as unticked)
active_zone, block_only_attacker, cant_have, choose_card, choose_color, choose_options, condition_compare, condition_filter, condition_kind, condition_valid, cost_sacrifice_filter, dice_range, dice_results, dice_sides, dig_until, dig_until_count, dig_until_filter, dig_until_found, dig_until_rest, dig_until_rest_pos, duration_param, grants_ability_api, grants_trigger, kicked_effect, kw_cost, library_position, loses_abilities, move_duration, move_filter, move_from, move_to, pay_color, pay_cost, pay_cost_discard_amount, pay_cost_energy_amount, pay_cost_sacrifice_amount, pay_mana_amount, pay_to_resolve, prevent_amount, protection_choice, removes, static_cost_amount, token_attached, token_gives_lifegain, token_tapped, trigger_blocker, trigger_counter, trigger_first_time, trigger_nth, x_mod, x_scope.
Every other family in TIER1_TAGS/STARTER_TAGS (249) existed in the previous committed run and counts as approved on 2026-10-22 (earlier families and gap families). To compute this list again: family = tag text before the colon, compared against `git show HEAD~1:...TIER1_TAGS.toon` and `STARTER_TAGS.toon`.
The reader vocabulary line in `blind_reader_prompt.md` already includes all new families.

## How to resume
1. Graders for round 2: the prompt in `blind_grader_prompt.md` with key `%TEMP%\tagtest_keys\B_r2\key_K.json`, recon `%TEMP%\tagtest_B\recon_r2\recon_K.txt`, output `%TEMP%\tagtest_B\grade_r2\grade_K.tsv`; 10 in one message, sonnet, low effort.
2. `python tools/concordia/deckgen/blind_test.py score C:/Users/olian/AppData/Local/Temp/tagtest_keys/B_r2 C:/Users/olian/AppData/Local/Temp/tagtest_B/grade_r2`
3. Concatenate grades into `tags/blind/B_r2_grades.tsv`; write `B_summary.md` (r1 vs r2, top gaps, wrong tags, fixes above, remaining; say r2 is flattered because the fixes came from these cards).
4. Cluster any new r2 gaps with `python tools/concordia/deckgen/blind_analyse.py KEY_DIR GRADE_DIR B AMOUNT TRIGGER_CONDITION ...` (prints Oracle, tags and grader note per gap label).
5. Steps 6-8 of the scheduled task: master doc, two Claude Docs with dropdowns, `OUTDATED_DOCS.md` and the `OUTDATED - delete:` rename, agent messages, `AGENT_TAG_REPORT.md` merge, final commit. Read the docs connector guide first; rebuild family counts from TIER1_TAGS.toon and STARTER_TAGS.toon.

## Process lessons (for the next run)
- `blind_test.py build` takes about 2 minutes (it tags 1000 cards) and exceeds the 120 s shell timeout. Run it with `run_in_background` and wait for the completion notice. A foreground `sleep` is blocked.
- Long bash heredocs containing apostrophes broke the shell parser twice; write scripts and documents with the Write tool and run them. Regex escapes inside a patch written as plain triple-quoted strings need `\\d`.
- Readers and graders took about 45 s each and kept to their tool limits (3 calls reported instead of 2, because the hand-back counts as one). Each costs roughly 75-120k tokens.
- `SendMessage` reaches only subagents of the same session; local agent sessions need `mcp__ccd_session_mgmt__send_message`.
- `TaskStop` stops background subagents by agent id; stopped graders leave no partial files.
- Samples A and B are disjoint (`--exclude`); round 2 must use `--same-as` so it measures the fix on identical cards.
- The fixes that help most come from Forge parameter families (`*Compare$`, `Destination$`, `K:` cost parts, chained `Cost$`), not from single cards. Most AMOUNT and TRIGGER_CONDITION gaps were script parameters the tagger ignored, not missing data.
