# Agent tag report (2026-10-22): analysis, utility and suggestions from the three claude2 agents

Collected by the claude2 main session for the user's review. Source: the agents' own files in `tags/agent_replies/` (deck-builder.md, forge-ai-lab.md, deck-balance-lab.md), written after being sent the tier 1 tag data (TIER1_TAGS.toon, STARTER_TAGS.toon, blind/A_summary.md, TAG_LINKS.md, H50-H58). They are low-effort agents working read-only under H55; nothing below has been acted on. Suggestions are advice only and need your `USER APPROVED` before any tag, deck or AI change.

## Checked by the main session against TIER1_TAGS.toon (2,131 cards)
| Claim | Agent | Result |
|---|---|---|
| few removal tags: `removal` 3, `ramp` 0, `board_wipe` 0, `sweeper` 0 | deck-builder, balance lab | confirmed (3, 0, 0, 0); `remove:*` and `damage` exist but there is no role layer |
| `evasion` 32, `mana_source` 117, `sacrifice_outlet` 154 | both | confirmed |
| 84 cards carry RemoveDeck | forge-ai-lab | confirmed (84) |
| `draw` 190 | deck-builder | confirmed |
| `draw` 462 | balance lab | not confirmed: 190 cards carry `draw`; the 462 looks like a different count |
| `kw:haste` 41 | balance lab | 39 in the file (close) |
Other counts in the agents' text were not rechecked.

## What each agent says tags are good for
- **deck-builder:** card identity, scaling and potential (`scales:`, `x_def`, token tags), structured triggers for commander support (H17, H38), type counts for creature bands (H11), tribal and land-type counts. Falls short on role quotas: no removal, ramp, sweeper or protection role tags; `x_def` values are raw Forge strings.
- **forge-ai-lab:** AI behaviour keys on the verb/API, not on `AILogic` (91% of cards have none). The 84 RemoveDeck cards cluster on choice effects (optional, sacrifice as cost, X, target by choice). Named AILogic values map to tag families (Pump, Curse, Fog, MakeUnblockable, AtOppEOT, Aristocrat, Never). Hypotheses for misplay (untested): optional plus sacrifice outlets, X without a target filter, reflexive and condition chains, scaling counts the AI does not value, end-of-turn pumps outside combat.
- **deck-balance-lab:** per-deck tag vectors (curve, mana sources, removal density, evasion, card advantage) can stratify the sim sample and explain win-rate outliers; a matchup matrix over three binary axes (evasion, removal-rich, ramp) has 8 cells instead of one per archetype pair.

## Suggestions, merged (agent ids in brackets)
| # | Suggestion | From | Overlap |
|---|---|---|---|
| 1 | Role layer: `role:removal`, `role:ramp`, `role:sweeper`, counterspell, protection | D1 D2 D3, S1 S3 (balance) | deck-builder and balance lab agree |
| 2 | Fast mana tag (`fast_mana`: non-land mana source, cost 2 or less) | S3 (balance) | related to D2 |
| 3 | Normalise `x_def` to `scales:<type>` plus a count rule; tag X kind (cost, count, target-dependent) | D4, S6 (ai-lab) | agree |
| 4 | Always tag filters (nonland, with flying, target side own/opp/any) | D5, S7 (ai-lab) | agree; matches the blind-test FILTER gap |
| 5 | Always set `effect_player` on discard, mill, draw | S4 (balance) | partly done in gap pass v2 |
| 6 | Make `evasion` consistent (`evasion:flying|menace|trample|unblockable`, include granted evasion) | S5 (balance) | `unblockable` now exists |
| 7 | Add API/verb and AI class to each `forge_ai:` line; keep exact RemoveDeck value and a reason class | S1 S2 (ai-lab) | |
| 8 | Keep AIPreference text as `ai_pref:` tags | S3 (ai-lab) | |
| 9 | Timing tag for tricks/pumps: `timing:combat` vs `timing:any` | S4 (ai-lab), D6 | related |
| 10 | Split `optional` into `optional:cost` and `optional:free` | S5 (ai-lab) | |
| 11 | `ai_never` and `ai_dep:combat` tags | S8 S9 (ai-lab) | |
| 12 | Token value tags (`token_pt`, `token_count` exist already) | S10 (ai-lab) | already present; the agent may not have seen them |
| 13 | `ai_risk` tag for cards with missing or flagged AILogic | S6 (balance) | overlaps 7 and 11 |
| 14 | A deck-by-tag count file (TOON) built from the tagger | S7 (balance) | a derived output, not a tag |
| 15 | Mana value per card (`mv`), synergy tags for discard-to-artifact decks | S2 (balance), D7 | |

## Conflicts and cautions
- No direct conflicts. Suggestions 7, 8, 11 and 13 add AI-side tags to a tagger whose rule (H54) treats Forge AI as the third, reference-only source; they need your decision before any work.
- Several agent claims are hypotheses (AI misplay combinations, correlation of tags with win rates). None was tested; sims are not approved.
- The agents did not know the blind-test result that amounts, conditions and filters are still the biggest gaps, so some suggestions (4, 5) overlap with fixes already planned.
- Keep role tags (1, 2) separate from ability tags: they are derived, and H52 says tags are ability-led.
