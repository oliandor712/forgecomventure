# Package index (claude2 tag project handoff, 2026-10-22)

Start with HANDOFF_FOR_CLAUDE.md. Then learning_data/README.md.

| Folder | Content |
|---|---|
| (root) | HANDOFF_FOR_CLAUDE.md, INDEX.md, git_log_since_push.txt, tagger_changes_since_push.patch |
| code/ | tagger (tag_run.py, tag_extra.py, tag_gaps.py, tag_tier1.py), blind test tools and prompts, TAG_LINKS.md design, KEYWORD_REFERENCE.toon |
| tags/ | current tag outputs (TIER1_TAGS.toon, STARTER_TAGS.toon), reports, approval list, agent report and replies, outdated-docs list |
| tags/blind/ | grades per round (tsv), A_summary.md, B_HANDOFF.md |
| learning_data/ | tag_to_text_pairs.jsonl (4000 rows) and README |
| rules_and_agents/ | human_logic.toon (H01-H58), main session brief, CONTEXT.md, kickoff prompt, update-file protocol, agent ids, CLAUDE.md |

Not included (outside the repo or private): the Forge game files, pool.pkl, scryfall bulk data, mtgish clone, Claude Doc contents (links are in HANDOFF_FOR_CLAUDE.md), the key files (they are in the learning data), subagent transcripts.

Files:

- HANDOFF_FOR_CLAUDE.md
- code/KEYWORD_REFERENCE.toon
- code/TAG_LINKS.md
- code/blind_analyse.py
- code/blind_grader_prompt.md
- code/blind_reader_prompt.md
- code/blind_test.py
- code/tag_extra.py
- code/tag_gaps.py
- code/tag_run.py
- code/tag_tier1.py
- git_log_since_push.txt
- learning_data/README.md
- learning_data/tag_to_text_pairs.jsonl
- rules_and_agents/CLAUDE.md
- rules_and_agents/CONTEXT.md
- rules_and_agents/MAIN_SESSION_BRIEF.md
- rules_and_agents/NEW_SESSION_PROMPT.md
- rules_and_agents/README.md
- rules_and_agents/claude2_agents.md
- rules_and_agents/human_logic.toon
- tagger_changes_since_push.patch
- tags/AGENT_TAG_REPORT.md
- tags/NEW_TAGS_FOR_APPROVAL.md
- tags/OUTDATED_DOCS.md
- tags/STARTER_TAGS.toon
- tags/STARTER_TAGS_REPORT.md
- tags/TAG_BLIND_TEST_20.md
- tags/TAG_FEEDBACK_STARTER_SAMPLE.md
- tags/TIER1_TAGS.toon
- tags/TIER1_TAGS_REPORT.md
- tags/agent_replies/deck-balance-lab.md
- tags/agent_replies/deck-builder.md
- tags/agent_replies/forge-ai-lab.md
- tags/blind/A_r1_grades.tsv
- tags/blind/A_r2_grades.tsv
- tags/blind/A_summary.md
- tags/blind/B_HANDOFF.md
- tags/blind/B_r1_grades.tsv
